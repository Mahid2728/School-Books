<?php
include 'connet.php';

      $id = $_POST['id'];
      $name = $_POST['name'];
      $author = $_POST['author'];
      $lite_dec = $_POST['lite_dec'];
      $old_pdf=$_POST['old_pdf'];
      $old_img=$_POST['old_img'];

  if (isset($_POST['submit'])) {

    if (isset($_FILES['full_dec']['name']) && ($_FILES['full_dec']['name'] !="")) {
      $siz=$_FILES['full_dec']['size'];
      $tem=$_FILES['full_dec']['tmp_name'];
      $typ=$_FILES['full_dec']['type'];
      $profile_nam=$_FILES['full_dec']['name'];
      //delete
      unlink("$old_pdf");
      //update
      $full_dec= 'upload_pdf/' .$profile_nam;
      move_uploaded_file($tem, $full_dec);
    }else{
      $full_dec=$old_pdf;
    }

    if (isset($_FILES['upload']['name']) && ($_FILES['upload']['name'] !="")) {
      $size=$_FILES['upload']['size'];
      $temp=$_FILES['upload']['tmp_name'];
      $type=$_FILES['upload']['type'];
      $profile_name=$_FILES['upload']['name'];
      //delete
      unlink("$old_img");
      //update
      $destinationfile= 'upload_images/' .$profile_name;
      move_uploaded_file($temp, $destinationfile);
    }else{
      $destinationfile=$old_img;
    }
    $update=mysqli_query($conn,"UPDATE sb SET name='$name',author='$author',lite_dec='$lite_dec',full_dec='$full_dec',upload='$destinationfile'  WHERE id='$id'");

    if ($update) {
      echo "<script>alert('update succes!')</script>";
    }else{
      echo "<script>alert('update faild!')</script>";
    }
}
echo "ok";



?>