<?php
session_start();

if($_SESSION['checked'] == "log") {
  if (isset($_GET['log'])==2) {
  echo "<script>alert('Login succes!')</script>";}
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <title>School Books</title>
  </head>
  <body>
<!-- navbar -->

  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="home.php">SB</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active text-info fw-bold" aria-current="page" href="home.php">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link  text-white fw-bold" href="blog_use.php">Blog</a>
        </li>
        <li class="nav-item">
          <a class="nav-link text-white fw-bold" href="about_use.php">About</a>
        </li>
        

      </ul>

 <button class="btn btn-danger"><a href="logout.php" class="text-decoration-none text-light">Logout</a></button>
    </div>
  </div>
</nav>
<!-- carousel -->
<div id="carouselExampleFade" class="carousel slide carousel-fade" data-bs-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="https://source.unsplash.com/1600x600/?books
" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="https://source.unsplash.com/1600x600/?school
" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="https://source.unsplash.com/1600x600/?education

" class="d-block w-100" alt="...">
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleFade" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleFade" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>

<!-- our books -->
<h1 class="text-primary text-center my-3">Our Books</h1>
<div class="container my-3">

  <h3>Class 6</h3>
  <!-- Set up your HTML -->
<div class="owl-carousel">

  <?php
      include 'connet.php';

        $sql = "SELECT * FROM sb";
        $result = $conn->query($sql);

if ($result->num_rows > 0) {
 
  // output data of each row
  while($row = $result->fetch_assoc()) {
    

    ?>
    <div class="col-md-3">
     <div class="card" style="width: 18rem;">
          <img src="<?php echo $row['upload']; ?>" class="card-img-top" height="200px" alt="...">
          <div class="card-body">
            <h5 class="card-title"> <?php echo $row['name']; ?> </h5>
            <h6 class="card-text"> <?php echo $row['author']; ?> </h6>
            <p class="card-text"><?php echo $row['lite_dec']; ?></p>
            <a href="<?php echo $row['full_dec'] ?>" download class="btn btn-primary">Download</a>
          </div>
        </div>
    </div>
        <?php
      }
      
    } else {
      echo "0 results";
    }
      ?>
</div>
</div>

<div class="container my-3">

  <h3>Class 7</h3>
  <!-- Set up your HTML -->
<div class="owl-carousel">

  <?php
      include 'connet.php';

        $sql = "SELECT * FROM c7";
        $result = $conn->query($sql);

if ($result->num_rows > 0) {
 
  // output data of each row
  while($row = $result->fetch_assoc()) {
    

    ?>
    <div class="col-md-3">
     <div class="card" style="width: 18rem;">
          <img src="<?php echo $row['upload']; ?>" class="card-img-top" height="200px" alt="...">
          <div class="card-body">
            <h5 class="card-title"> <?php echo $row['name']; ?> </h5>
            <h6 class="card-text"> <?php echo $row['author']; ?> </h6>
            <p class="card-text"><?php echo $row['lite_dec']; ?></p>
            <a href="<?php echo $row['full_dec'] ?>" download class="btn btn-primary">Download</a>
          </div>
        </div>
    </div>
        <?php
      }
      
    } else {
      echo "0 results";
    }
      ?>
</div>
</div>
    <!-- Optional JavaScript; choose one of the two! -->
 <script src="js/jquery.min.js"></script>
      <script src="js/owl.carousel.min.js"></script>
      <script>
         $(document).ready(function(){
          $(".owl-carousel").owlCarousel();
         });
      </script>

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
    -->
  </body>
</html>
<hr>
<p class="text-center">Copyright @ 2021 by SB</p>
<?php
}else{
header("Location:login.php");
} ?>