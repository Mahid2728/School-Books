<?php
include 'connet.php';

if(isset($_POST['loging'])) {
	$Email=$_POST['Email'];
	$Password=$_POST['Password'];
}


$sql = "SELECT * FROM user_acc WHERE Email='$Email' AND Password='$Password' ";
		 $result = mysqli_query($conn, $sql);

				 if (mysqli_num_rows($result) > 0) {
					session_start();
					$_SESSION['checked'] = "log";
					header('Location: home.php?log=2');
				}else{
					header('Location: login.php?log=1');
				}
?>
