<?php
include 'connet.php';

$Name=$_POST['Name'];
$Email=$_POST['Email'];
$Subject=$_POST['Subject'];
$massage=$_POST['massage'];


$sql = "INSERT INTO feedback (Name, Email , Subject, massage)
          VALUES ('$Name', '$Email', '$Subject','$massage')";

          if ($conn->query($sql) === TRUE) {
            echo "ok";
          } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
          }
?>