-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 29, 2021 at 02:21 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sb`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `pass` varchar(50) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `Email`, `pass`, `date`) VALUES
(1, 'mahid2728@gmail.com', 'admin', '2021-11-27 11:22:39');

-- --------------------------------------------------------

--
-- Table structure for table `blog`
--

CREATE TABLE `blog` (
  `id` int(11) NOT NULL,
  `Title` varchar(50) NOT NULL,
  `Description` varchar(300) NOT NULL,
  `Img` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `blog`
--

INSERT INTO `blog` (`id`, `Title`, `Description`, `Img`) VALUES
(7, ' Frank X. Shaw - Corporate Vice President, Communi', 'The last 18 months have resulted in a sea change throughout every industry – from the adoption of telehealth in healthcare to digital wallets in financial services to curbside pickup and contactless shopping in retail – and digital technology has been at the forefront of this seismic shift.', 'Blog_img/Mesh-for-Teams-slide-6-960x540.png');

-- --------------------------------------------------------

--
-- Table structure for table `blog_2`
--

CREATE TABLE `blog_2` (
  `id` int(11) NOT NULL,
  `Title` varchar(50) NOT NULL,
  `Description` varchar(300) NOT NULL,
  `Img` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `blog_2`
--

INSERT INTO `blog_2` (`id`, `Title`, `Description`, `Img`) VALUES
(3, 'Frank X. Shaw - Corporate Vice President, Communic', 'In our jobs as storytellers for Microsoft, we’re called to improve our storytelling every day, and the best way I’ve found to do this is to look at great stories – whatever the form – and learn from them. That’s why I’m especially excited to team up with the National Association of Black Journalists', 'Blog_img_2/JMJ_9590-1-480x270.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `c7`
--

CREATE TABLE `c7` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `author` varchar(50) NOT NULL,
  `lite_dec` varchar(60) NOT NULL,
  `full_dec` varchar(250) NOT NULL,
  `upload` varchar(250) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` tinyint(4) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `c7`
--

INSERT INTO `c7` (`id`, `name`, `author`, `lite_dec`, `full_dec`, `upload`, `date`, `status`) VALUES
(1, 'Bangla 1st', 'NCTB Books Of Class 7', 'NCTB books of class 6 are available here. Here I’m going to ', 'upload_pdf/Class - 7 Bangla - (BDeBooks.com).pdf', 'upload_images/Screenshot 2021-11-29 081912.jpg', '2021-11-29 13:19:43', 1);

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` int(11) NOT NULL,
  `Name` varchar(12) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Subject` varchar(30) NOT NULL,
  `massage` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `Name`, `Email`, `Subject`, `massage`) VALUES
(1, 'mahid', '', 'nonwe', 'dsgsdghdhg'),
(2, 'mahid', '', 'nonwe', 'dsgsdghdhg'),
(3, 'mahid', 'mahid6258@gmail.com', 'nonwe', 'hghlfh;l');

-- --------------------------------------------------------

--
-- Table structure for table `sb`
--

CREATE TABLE `sb` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `author` varchar(100) NOT NULL,
  `lite_dec` varchar(60) NOT NULL,
  `full_dec` varchar(300) NOT NULL,
  `upload` varchar(255) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` tinyint(4) NOT NULL DEFAULT 1 COMMENT '1 or 0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sb`
--

INSERT INTO `sb` (`id`, `name`, `author`, `lite_dec`, `full_dec`, `upload`, `date`, `status`) VALUES
(14, 'Bangla 1st', 'NCTB Books Of Class 6', 'NCTB books of class 6 are available here. Here I’m going to ', 'upload_pdf/Secondary - 2018 - class - 6 - Anondo Pat-6 PDF BV Web .pdf', 'upload_images/Screenshot 2021-11-29 081409.jpg', '2021-11-29 13:14:27', 1);

-- --------------------------------------------------------

--
-- Table structure for table `user_acc`
--

CREATE TABLE `user_acc` (
  `id` int(11) NOT NULL,
  `Name` varchar(30) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Password` varchar(10) NOT NULL,
  `Address` varchar(50) NOT NULL,
  `City` varchar(10) NOT NULL,
  `country` varchar(3) NOT NULL,
  `Zip` int(6) NOT NULL,
  `Gender` varchar(6) NOT NULL,
  `Age` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_acc`
--

INSERT INTO `user_acc` (`id`, `Name`, `Email`, `Password`, `Address`, `City`, `country`, `Zip`, `Gender`, `Age`) VALUES
(1, 'hsh', 'fghfgh@gmail.com', 'hfsethad', 'shgg', 'fgh', 'BD', 5800, 'Male', 18);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blog`
--
ALTER TABLE `blog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blog_2`
--
ALTER TABLE `blog_2`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `c7`
--
ALTER TABLE `c7`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sb`
--
ALTER TABLE `sb`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_acc`
--
ALTER TABLE `user_acc`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `blog`
--
ALTER TABLE `blog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `blog_2`
--
ALTER TABLE `blog_2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `c7`
--
ALTER TABLE `c7`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `sb`
--
ALTER TABLE `sb`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `user_acc`
--
ALTER TABLE `user_acc`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
