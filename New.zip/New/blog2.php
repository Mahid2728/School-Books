<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sb";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if(isset($_POST['submit'])){
  $Title=$_POST['Title'];
  $Description=$_POST['Description'];
  $Img=$_FILES['Img'];

  $filename=$Img['name'];
  $fileerror=$Img['error'];
  $filetemp=$Img['tmp_name'];

  $fileext= explode('.',$filename);
  $filecheck= strtolower(end($fileext));

  $fileextstored= array('png','jpg','jpeg');

  if (in_array($filecheck, $fileextstored)) {
    $destinationfile= 'Blog_img/' .$filename;
      move_uploaded_file($filetemp, $destinationfile);

      $q="INSERT INTO `blog`(`Title`, `Description`, `Img`) 
          VALUES ('$Title', '$Description','$destinationfile')";

      // $q ="INSERT INTO `sb`(`name`,`upload`) 
      //     VALUES ('$name','$destinationfile')";

      $query = mysqli_query($conn, $q);
  }
}

echo "ok";
?>