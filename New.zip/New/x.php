<?php
if(isset($_POST['update_img'])){

  $id = $_POST['id'];
  $Title = $_POST['Title'];
  $Description = $_POST['Description'];

  $new_img=$_FILES['img']['name'];

  $old_img=$_POST['old_img'];

  if($new_img !=''){
    $update_filename = $new_img;
  }
  else{
    $update_filename = $old_img;
  }

  if (file_exists("Blog_img/.$_FILES['img']['name']")) {
    $filename = $_FILES['img']['name'];
    $_SESSION['status'] = "image already Exists".$filename;
    // header(string)
  }
  else{
      // up
    $q= "UPDATE blog SET Title='$Title',Description='$Description',Img='$destinationfile'  WHERE id='$id' ";
      $query = mysqli_query($conn, $q);

    if($query_run){

      if ($_FILES['img']['name'] !='') {
        move_uploaded_file($_FILES['img']['tep_name'], "Blog_img/".$_FILES['img']['name']);
        unlink("Blog_img/".$old_img);
      }

      $_SESSION['status'] = "up succs"
      // header(string)
    }
    else{
      $_SESSION['status'] = "up not "
      // header(string)
    }
  }
}
?>








<?php
session_start();
include 'connet.php';
if(isset($_POST['submit'])){

  $id = $_POST['id'];
  $Title = $_POST['Title'];
  $Description = $_POST['Description'];

  $new_img=$_FILES['img']['name'];

  $old_img=$_POST['old_img'];

  if($new_img !=''){
    $update_filename = $new_img;
  }
  else{
    $update_filename = $old_img;
  }

  if (file_exists("Blog_img/".$_FILES['img']['name'])) {
    $filename = $_FILES['img']['name'];
    $_SESSION['status'] = "image already Exists".$filename;
    header(Location: view_blog_update.php);
  }
  else{
      // up
    $q= "UPDATE blog SET Title='$Title',Description='$Description',Img='$update_filename'  WHERE id='$id' ";
      $query = mysqli_query($conn, $q);

    if($query_run){

      if ($_FILES['img']['name'] !='') {
        move_uploaded_file($_FILES['img']['tep_name'], "Blog_img/".$_FILES['img']['name']);
        unlink("Blog_img/".$old_img);
      }

      // $_SESSION['status'] = "up succs"
      // // header(string)
    }
    else{
      // $_SESSION['status'] = "up not "
      // // header(string)
    }
  }
}
echo "ok";




if (isset($_POST('submit'))) {
  $name=$_POST['name'];

  if (isset($_FILES['profile']['name']) && ($_FILES['prodile']['name'])) {
    $size=$_FILES['profile']['size'];
    $temp=$_FILES['profile']['tmp_name'];
    $type=$_FILES['profile']['type'];
    $profile_name=$_FILES['profile']['name'];
    //delete
    unlink("profile_img/$old_img");
    //update
    move_uploaded_file($temp, "profile_img/$profile_name");
  }else{
    $profile_name=$old_img;
  }
  $update=mysql_query()

  if ($update) {
    echo "<script>alert('update succes!')</script>";
  }else{
    echo "<script>alert('update faild!')</script>";
  }
}
?>





















<?php
if(isset($_POST['submit'])){
  $name=$_POST['name'];
  $author=$_POST['author'];
  $type=$_POST['type'];
  $upload=$_FILES['upload'];

  $filename=$upload['name'];
  $fileerror=$upload['error'];
  $filetemp=$upload['tmp_name'];

  $fileext= explode('.',$filename);
  $filecheck= strtolower(end($fileext));

  $fileextstored= array('png','jpg','jpeg');

  if (in_array($filecheck, $fileextstored)) {
    $destinationfile= 'upload_images/' .$filename;
      move_uploaded_file($filetemp, $destinationfile);

      $q="INSERT INTO `sb`(`name`, `author`, `type`, `upload`) 
          VALUES ('$name', '$author', '$type','$destinationfile')";

      // $q ="INSERT INTO `sb`(`name`,`upload`) 
      //     VALUES ('$name','$destinationfile')";

      $query = mysqli_query($conn, $q);
  }
}


?>

