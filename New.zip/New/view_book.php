 <?php  
  include 'connet.php';
$id=$_GET['id'];

$sql = "SELECT * FROM sb WHERE id='$id'" ;
$result = mysqli_query($conn, $sql);


while($row = mysqli_fetch_assoc($result)) {
  $ro=$row;
}

$file1='echo $ro['full_dec'];'
header('Content-type: application/pdf');
header('Content-Disposition: inline; filename"'.$file1 .'"');
header('Content-Transfer-Encoding: binary');
header('Accept-Ranges: bytes');
@readfile($file1);
?>
