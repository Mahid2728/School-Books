<?php
// include 'connet.php';

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sb";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if(isset($_POST['submit'])){
  $name=$_POST['name'];
  $author=$_POST['author'];
  $lite_dec=$_POST['lite_dec'];

  $full_dec=$_FILES['full_dec'];
  $filname=$full_dec['name'];
  $filerror=$full_dec['error'];
  $filtemp=$full_dec['tmp_name'];

  $filext= explode('.',$filname);
  $filcheck= strtolower(end($filext));

  $filextstored= array('pdf');

  if (in_array($filcheck, $filextstored)) {
    $destinationfil= 'upload_pdf/' .$filname;
      move_uploaded_file($filtemp, $destinationfil);}
      // -----

  $upload=$_FILES['upload'];
  $filename=$upload['name'];
  $fileerror=$upload['error'];
  $filetemp=$upload['tmp_name'];

  $fileext= explode('.',$filename);
  $filecheck= strtolower(end($fileext));

  $fileextstored= array('png','jpg','jpeg');

  if (in_array($filecheck, $fileextstored)) {
    $destinationfile= 'upload_images/' .$filename;
      move_uploaded_file($filetemp, $destinationfile);

      $q="INSERT INTO `sb`(`name`, `author`, `lite_dec`, `full_dec`, `upload`) 
          VALUES ('$name', '$author','$lite_dec','$destinationfil','$destinationfile')";

      $query = mysqli_query($conn, $q);
  }
}

header("Location:admin.php");
?>