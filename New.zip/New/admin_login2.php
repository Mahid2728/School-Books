<?php
include 'connet.php';

if(isset($_POST['loging'])) {
	$Email=$_POST['Email'];
	$pass=$_POST['pass'];
}


$sql = "SELECT * FROM admin WHERE Email='$Email' AND pass='$pass' ";
		 $result = mysqli_query($conn, $sql);

				 if (mysqli_num_rows($result) > 0) {
					session_start();
					$_SESSION['checked'] = "log";
					header('Location: admin.php?log=2');
				}else{
					header('Location: admin_login.php?log=1');
				}
?>