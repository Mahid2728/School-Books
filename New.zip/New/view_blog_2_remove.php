<?php
include 'connet.php';
$id=$_GET['id'];

            $sql = "DELETE FROM blog_2 WHERE id='$id' ";

				if (mysqli_query($conn, $sql)) {
                    // include 'main_page_remove_alart.php';
                    echo "ok";
				} else {
				  echo "Error deleting record: " . mysqli_error($conn);
				}
header("Location:admin.php");
        ?>