<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>

    <title>Hello, world!</title>
  </head>
  <body>

    <!-- 1st_page -->
    <div class="img-fluid" style="background-image: url(index_/bg-1.jpg); height: 500px;">
    <div class="container">
      <div class="row py-3">
        <div class="col-6"><div class="navbar-brand col-md-4 text-info">SB</div></div>

    <div class="col-6">
    <ul class="nav justify-content-end">
    <li class="nav-item">
      <a class="nav-link text-decoration-none  text-info fw-bold" href="index.php">Home</a>
    </li>
    <li class="nav-item">
      <a class="nav-link text-decoration-none  text-white fw-bold" href="blog_page.php">Blog</a>
    </li>
    <li class="nav-item">
      <a class="nav-link text-decoration-none  text-white fw-bold" href="About.php">About</a>
    </li>
    <li class="nav-item">
      <button type="button" class="btn btn-success" data-bs-toggle="modal"
      data-bs-target="#JoinModal">Join Now</button>
    </li>
  </ul></div>

<!-- join_modal -->
 <div class="modal fade" id="JoinModal" tabindex="-1" aria-labelledby="JoinModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="JoinModalLabel">Sign Up</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form class="row g-3" action="join.php" method="POST" >
                        <div class="col-md-6">
                            <label class="form-label">Name</label>
                            <input type="text" class="form-control" name="Name" required>
                        </div>

                        <div class="col-md-6">
                            <label for="inputEmail4" class="form-label">Email</label>
                            <input type="email" class="form-control" id="inputEmail4" name="Email" required>
                        </div>
                        <div class="col-md-6">
                            <label for="inputPassword4" class="form-label">Password</label>
                            <input type="password" class="form-control" id="inputPassword4" name="Password" required>
                        </div>
                        <div class="col-12">
                            <label for="inputAddress" class="form-label">Address</label>
                            <input type="text" class="form-control" id="inputAddress" placeholder="1234 Main St" name="Address" required>
                        </div>
                        <div class="col-md-6">
                            <label for="inputCity" class="form-label">City</label>
                            <input type="text" class="form-control" id="inputCity"  name="City" required>
                        </div>
                        <div class="col-md-4">
                            <label for="inputState" class="form-label">country</label>
                            <select id="inputState" class="form-select" name="country" required>
                                <option selected>Choose...</option>
                                <option>US</option>
                                <option>UK</option>
                                <option>BD</option>
                                <option>CA</option>
                                <option>AU</option>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <label for="inputZip" class="form-label">Zip</label>
                            <input type="text" class="form-control" id="inputZip" name="Zip" required>
                        </div>
                        <div class="col-md-3">
                            <label for="inputState2" class="form-label">Gender</label>
                            <select id="inputState2" class="form-select" name="Gender" required>
                                <option selected>Choose...</option>
                                <option>Male</option>
                                <option>Female</option>
                            </select>
                            
                        </div>
                        <div class="col-md-3">
                            <label for="inputZip2" class="form-label">Age</label>
                            <input type="number" class="form-control" id="inputZip2" name="Age" required>
                        </div>
                        <div class="col-12">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="gridCheck">
                                <label class="form-check-label" for="gridCheck">
                                    Agree <small class="text-secondary">our <a href="#">Terms</a>,<a href="#"> Data
                                            Policy </a> and <a href="#">Cookie</a> Policy.</small>
                                </label>
                            </div>
                        </div>
                        <div class="col-12">
                            <button type="submit" class="btn btn-primary">Sign Up</button>
                            <a href="login.php" class="text-decoration-none">Login</a>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    <!-- ------------ -->
    </div>
    <div class="col-md-6 m-auto text-center my-5 text-white">
      <h1 class="my-3">Weclome to SB</h1>
        <hr class="border-bottom border-info border-2 col-md-2 m-auto">
    <p class="my-5">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>

    <a href="#" class="text-decoration-none text-info border border-2 border-info px-2 py-1 my-5">LEARN MORE</a>
    </div>
    </div>
    </div>

<!-- 2nd_page -->
<div class="container">
  <div class="row my-5">
    <div class="col-2"></div>
    <div class="col-3"><img src="index_/bg-logo.png" class="img-fluid"></div>
    <div class="col-5">
      <h4>OUR STORY</h4>
      <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley</p>
      <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley</p>
      <a href="#" class="text-decoration-none text-info border border-2 border-info px-2 py-1 my-5">LEARN MORE</a>
    </div>
    <div class="col-2"></div>
  </div>
</div>

<!-- 3nd_page -->
<div class="img-fluid" style="background-image: url(index_/bg-2.jpg); height: 400px;">
  <div class="col-md-4 m-auto text-center">
  <a href="#"><i class="far fa-play-circle text-white display-1" style="margin-top: 150px;">
  </i></a>
  <h4 class="text-white fw-normal mt-2">WATCH OUR STORY</h4>
  
  </div>
</div>

<!-- 4th_page -->
<div class="container my-3">
  <div class="text-center my-3">
    <h3>EXPERTISE</h3>
      <p>Lorem ipsum dolor sit amet proin gravida nibh vel velit</p>
  </div>

  <div class="row text-center">
    <div class="col-4">
      <i class="fas fa-desktop text-info display-5 my-3"></i>
          <h5 class="my-2">WEB DESIGN & DEVELOPMENT</h5>
          <p>This is Photoshop's version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet Aenean.</p>
    </div>
    <div class="col-4">
      <i class="fas fa-paint-brush text-info display-5 my-3"></i>
          <h5 class="my-2">BRANDING IDENTITY</h5>
          <p>This is Photoshop's version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet Aenean.</p>
    </div>
    <div class="col-4">
      <i class="fas fa-mobile-alt text-info display-5 my-3"></i>
          <h5 class="my-2">MOBILE APP</h5>
          <p>This is Photoshop's version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet Aenean.</p>
    </div>
    <div class="col-4">
      <i class="fas fa-chart-pie text-info display-5 my-3"></i>
          <h5 class="my-2">SEARCH ENGINE OPTIMIZATION</h5>
          <p>This is Photoshop's version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet Aenean.</p>
    </div>
    <div class="col-4">
      <i class="fas fa-gamepad text-info display-5 my-3"></i>
          <h5 class="my-2">GAME DEVELOPMENT</h5>
          <p>This is Photoshop's version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet Aenean.</p>
    </div>
    <div class="col-4">
      <i class="far fa-heart text-info display-5 my-3"></i>
          <h5 class="my-2">MADE WITH LOVE</h5>
          <p>This is Photoshop's version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet Aenean.</p>
    </div>
  </div>
</div>

<!-- 5th_page -->
<div class="py-5" style="background-image: url(index_/bg-3.jpg); height: 700px;">
<div class="container my-3">
  <div class="text-center text-white">
    <h3>MEET OUR AMAZING TEAM</h3>
      <p>Lorem ipsum dolor sit amet proin gravida nibh vel velit</p>
  </div>
  <hr class="border-bottom border-info border-2 col-md-1 m-auto">

  <div class="row my-5">
    <div class="col-3">
      <div class="card" style="width: 18rem;">
  <img src="..." class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Card title</h5>
    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
    <a href="#" class="btn btn-primary">Go somewhere</a>
  </div>
</div>
    </div>
    <div class="col-3">
      <div class="card" style="width: 18rem;">
  <img src="..." class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Card title</h5>
    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
    <a href="#" class="btn btn-primary">Go somewhere</a>
  </div>
</div>
    </div>
    <div class="col-3">
      <div class="card" style="width: 18rem;">
  <img src="..." class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Card title</h5>
    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
    <a href="#" class="btn btn-primary">Go somewhere</a>
  </div>
</div>
    </div>
    <div class="col-3">
      <div class="card" style="width: 18rem;">
  <img src="..." class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Card title</h5>
    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
    <a href="#" class="btn btn-primary">Go somewhere</a>
  </div>
</div>
    </div>
  </div>
  <div class="text-center">
      <p class="text-white">Become part of our dream team, let’s join us ! </p>
   <a href="#" class="text-decoration-none text-info border border-2 border-info px-2 py-1 my-5">WE ARE HIRING</a>
  </div>
</div>
</div>

<!-- 6th_page -->
<div class="col-md-5 text-center m-auto my-5">
  <h3 class="mb-3">GIVE US YOUR FEEDBACK</h3>
  <form action="FEEDBACK.php" method="POST">
    <div class="mb-2"><input type="text" name="Name" placeholder="Name" class="form-control"></div>
    <div class="mb-2"><input type="text" name="E-mail" placeholder="E-mail" class="form-control"></div>
    <div class="mb-2"><input type="text" name="Subject" placeholder="Subject" class="form-control"></div>
    <div class="mb-2"><textarea class="form-control" name="massage" placeholder="Your massage"></textarea></div>
    <button class="btn text-info border border-2 border-info" type="submit">SUBMIT</button>
  </form>
</div>

<hr>
<p class="text-center">Copyright @ 2021 by SB</p>
    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
    -->
  </body>
</html>