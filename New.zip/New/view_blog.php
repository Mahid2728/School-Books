<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

    <title>SB-welcome to admin page</title>
  </head>
  <body>

  <?php include 'navbar.php'; ?>


<div class="col-md-3 my-3 mx-auto text-center text-success border-bottom"> <h3>Admin View Page</h3> </div>

<div class="container col-md-8">
<table class="table table-hover m-auto">
  <thead>
    <tr class="text-center">
      <th scope="col">#</th>
      <th scope="col">Title</th>
      <th scope="col">Desc</th>
      <th scope="col">Img</th>
      <th scope="col">Edit</th>
    </tr>
  </thead>
  <tbody>
  <?php
      include 'connet.php';

        $sql = "SELECT * FROM blog";
        $result = $conn->query($sql);

        $x=1;

if ($result->num_rows > 0) {
 
  // output data of each row
  while($row = $result->fetch_assoc()) {
    

    ?>
    <tr>
      <th scope="row"><?php echo $x++; ?></th>
      <td><?php echo $row['Title']; ?></td>
      <td><?php echo $row['Description']; ?></td>
      <td><img src="<?php echo $row['Img']; ?>" height="100px"></td>
      <td>
        <a href="view_blog_update.php?id=<?php echo $row['id'] ?>" class="btn btn-success">Update</a>
        <a href="view_blog_remove.php?id=<?php echo $row['id'] ?>" class="btn btn-danger">Remove</a>
      </td>
    </tr>

    <?php
      }
      
    } else {
      echo "0 results";
    }
      ?>
  </tbody>

</table>
</div>


    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
    -->
  </body>
</html>