<?php
session_start();

if($_SESSION['checked'] == "log") {
  if (isset($_GET['log'])==2) {
  echo "<script>alert('Login succes!')</script>";
}
  
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

    <title>SB-welcome to admin page</title>
  </head>
  <body>
<?php include 'navbar.php'; ?>

 <div class="container">
     <div class="col-md-3 my-3 mx-auto text-center text-success"> <h3>Admin Page</h3> </div>
     <hr>

     <!-- from -->
     <div class="contaner">
  <div class="row my-3">
    <div class="col"></div>
    <div class="col-5">
      <h1 class="text-info text-center">Add New Books</h1>
      <hr>


      <form class="my-3" action="class7_update_2.php" method="POST" enctype="multipart/form-data">
               <?php  
  include 'connet.php';
$id=$_GET['id'];

$sql = "SELECT * FROM c7 WHERE id='$id'" ;
$result = mysqli_query($conn, $sql);


while($row = mysqli_fetch_assoc($result)) {
  $ro=$row;
}
?>
        <input type="hidden" name="id" value="<?php echo $ro['id']; ?>">
        <div class="row mb-3">
        <label for="book_name" class="col col-form-label">Name</label>
        <div class="col-10">
        <input type="text" class="form-control" name="name" placeholder="book name" value="<?php echo $ro['name'] ?>" id="book_name">
        </div>
        </div>

        <div class="row mb-3">
        <label for="author_name" class="col col-form-label">Author</label>
        <div class="col-10">
        <input type="text" class="form-control" name="author" placeholder="author name"  value="<?php echo $ro['author'] ?>" id="author_name">
        </div>
        </div>

        <div class="row mb-3">
        <label for="lite_dec" class="col col-form-label">Lite Dec</label>
        <div class="col-10">
        <textarea class="form-control" name="lite_dec" placeholder="<?php echo $ro['lite_dec'] ?>"  value="" id="lite_dec"></textarea>
        </div>
        </div>

        <div class="row mb-3">
        <label for="full_dec" class="col col-form-label">Full Dec</label>
        <div class="col-10">
          <input type="hidden" name="old_pdf" value="<?php echo $ro['full_dec'] ?>">
        <input type="file" class="form-control" name="full_dec" id="full_dec">
        </div>
        </div>

        <div class="row mb-3">
          <label class="col col-form-label">Upload</label>
          <div class="col-10">
             <img src="<?php echo $ro['upload'] ?>" height="120px">
            <input type="hidden" name="old_img" value="<?php echo $ro['upload'] ?>">
            <input type="file" name="upload" value="" class="form-control">
          </div>
        </div>

            <button class="btn btn-success" name="submit" type="submit">Add</button>
      </form>
    </div>
    <div class="col"></div>
  </div>
</div>


 </div>

    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
    -->
  </body>
</html>
<?php
}else{
  header("Location:admin_login.php");
} ?>