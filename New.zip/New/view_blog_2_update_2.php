<?php
include 'connet.php';

      $id = $_POST['id'];
      $Title = $_POST['Title'];
      $Description = $_POST['Description'];
      $old_img=$_POST['old_img'];

  if (isset($_POST['submit'])) {

    if (isset($_FILES['Img']['name']) && ($_FILES['Img']['name'] !="")) {
      $size=$_FILES['Img']['size'];
      $temp=$_FILES['Img']['tmp_name'];
      $type=$_FILES['Img']['type'];
      $profile_name=$_FILES['Img']['name'];
      //delete
      unlink("$old_img");
      //update
      $destinationfile= 'Blog_img_2/' .$profile_name;
      move_uploaded_file($temp, $destinationfile);
    }else{
      $destinationfile=$old_img;
    }
    $update=mysqli_query($conn,"UPDATE blog_2 SET Title='$Title',Description='$Description',Img='$destinationfile'  WHERE id='$id'");

    if ($update) {
      echo "<script>alert('update succes!')</script>";
    }else{
      echo "<script>alert('update faild!')</script>";
    }
}
header("Location:admin.php");



?>